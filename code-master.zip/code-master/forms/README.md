# ng-book 2: Forms Chapter

This example is more sophisticated than some of the others in that it uses Webpack for building the files instead of using `tsc` directly. 

To install:

    npm install

To run:

    npm run go

Then visit [http://localhost:8080](http://localhost:8080)
