/// <reference path="browser/ambient/angular-ui-router/index.d.ts" />
/// <reference path="browser/ambient/angular/index.d.ts" />
/// <reference path="browser/ambient/es6-shim/index.d.ts" />
/// <reference path="browser/ambient/jquery/index.d.ts" />
/// <reference path="browser/ambient/underscore/index.d.ts" />
